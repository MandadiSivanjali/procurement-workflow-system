# Procurement Workflow System - DevifyX Assignment

## Overview
This project implements a MySQL-only backend system for managing procurement requests, multi-level approvals, and supplier interactions.

## Features Implemented
- User & Role Management
- Purchase Requests
- Multi-level Approval Workflow
- Supplier Profiles
- Request Status Tracking
- Audit Logs with Triggers
- Item Catalog
- Supplier Interaction Logs

## Files Included
- `schema.sql` - Table creation scripts
- `sample_data.sql` - Sample data insertions
- `queries.sql` - Core feature and reporting queries
- `procedures_triggers.sql` - Stored procedures and triggers
- `README.md` - Documentation and usage

## Requirements
- MySQL 8.0+

## How to Use
1. Run `schema.sql` to create the database structure.
2. Run `sample_data.sql` to populate sample data.
3. Use `queries.sql` for executing reports.
4. Run `procedures_triggers.sql` to create procedures and triggers.
