-- sample_data.sql: Sample data insertions

INSERT INTO Roles (role_name) VALUES ('Manager'), ('Finance'), ('Admin'), ('Employee');

INSERT INTO Users (name, email, role_id) VALUES 
('Alice', 'alice@example.com', 4),
('Bob', 'bob@example.com', 1),
('Carol', 'carol@example.com', 2);

INSERT INTO Suppliers (supplier_name, contact_info) VALUES
('ABC Supplies', 'abc@supplies.com'),
('XYZ Traders', 'xyz@traders.com');

INSERT INTO Items (item_name, item_description) VALUES
('Laptop', 'Dell XPS 15'),
('Monitor', '24 inch LED Display');

INSERT INTO PurchaseRequests (user_id, item_id, quantity) VALUES
(1, 1, 2),
(1, 2, 1);

INSERT INTO Approvals (request_id, approver_id, approval_level) VALUES
(1, 2, 'Manager'),
(2, 2, 'Manager');

INSERT INTO SupplierInteractions (supplier_id, user_id, message) VALUES
(1, 1, 'Requested price quote for 2 laptops.'),
(2, 1, 'Requested availability for monitors.');
