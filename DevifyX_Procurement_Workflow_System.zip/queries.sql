-- queries.sql: Sample queries

-- Pending approvals
SELECT * FROM PurchaseRequests WHERE status = 'Pending';

-- Approved requests with approver details
SELECT pr.request_id, u.name AS requested_by, a.approval_level, a.decision
FROM PurchaseRequests pr
JOIN Approvals a ON pr.request_id = a.request_id
JOIN Users u ON pr.user_id = u.user_id
WHERE a.decision = 'Approved';

-- Supplier performance (based on interactions)
SELECT s.supplier_name, COUNT(si.interaction_id) AS interactions
FROM SupplierInteractions si
JOIN Suppliers s ON si.supplier_id = s.supplier_id
GROUP BY si.supplier_id;
