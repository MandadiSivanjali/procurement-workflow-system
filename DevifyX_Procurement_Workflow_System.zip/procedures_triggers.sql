-- procedures_triggers.sql: Triggers and Procedures

-- Trigger for audit log on status update
DELIMITER //
CREATE TRIGGER log_status_update
AFTER UPDATE ON PurchaseRequests
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO AuditLogs (request_id, action, performed_by)
        VALUES (NEW.request_id, CONCAT('Status changed to ', NEW.status), NEW.user_id);
    END IF;
END;
//
DELIMITER ;

-- Stored procedure to submit request
DELIMITER //
CREATE PROCEDURE SubmitRequest(IN uid INT, IN item INT, IN qty INT)
BEGIN
    INSERT INTO PurchaseRequests (user_id, item_id, quantity) VALUES (uid, item, qty);
END;
//
DELIMITER ;
